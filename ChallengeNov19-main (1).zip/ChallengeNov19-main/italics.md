These are markdown _italics_. You can use italics when you want to stress an important word in a sentence. For example... I do not want to go to the store, but _you_ can.

[Back to readme](README.md)
