In markdown **bold** words are used similar to italics. They can **stress** a word.

[Back to readme](README.md)
