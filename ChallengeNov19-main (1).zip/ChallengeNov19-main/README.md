# ChallengeNov19

In this Challenge I will...
- build pages
- use markdown features
- and hope I am doing it right

[Italics](italics.md)

[Bold](bold.md)

[Strike Through](strkthru.md)

[Block Quote](blkqt.md)
