The ~~strike though~~ can be used to show something that is incorrect. Such as I will ~~not~~ pass this class.

[Back to readme](README.md)
